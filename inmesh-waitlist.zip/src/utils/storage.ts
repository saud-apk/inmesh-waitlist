import { WaitlistSubmission } from '../types';

const STORAGE_KEY = 'inmesh_waitlist_records';
const BASE_STUDENT_COUNT = 2847;

export function getStoredSubmissions(): WaitlistSubmission[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function getTotalWaitlistCount(): number {
  const submissions = getStoredSubmissions();
  return BASE_STUDENT_COUNT + submissions.length;
}

export function findExistingSubmission(email: string): WaitlistSubmission | undefined {
  const submissions = getStoredSubmissions();
  const normalizedEmail = email.trim().toLowerCase();
  return submissions.find((sub) => sub.email.trim().toLowerCase() === normalizedEmail);
}

export function addWaitlistSubmission(email: string, college: string): { submission: WaitlistSubmission; isDuplicate: boolean } {
  const existing = findExistingSubmission(email);
  if (existing) {
    return { submission: existing, isDuplicate: true };
  }

  const submissions = getStoredSubmissions();
  const spotNumber = BASE_STUDENT_COUNT + submissions.length + 1;

  const newSubmission: WaitlistSubmission = {
    id: 'sub_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
    email: email.trim().toLowerCase(),
    college: college.trim(),
    timestamp: Date.now(),
    spotNumber,
  };

  submissions.push(newSubmission);

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(submissions));
  } catch (err) {
    console.warn('Failed to persist to localStorage:', err);
  }

  return { submission: newSubmission, isDuplicate: false };
}
