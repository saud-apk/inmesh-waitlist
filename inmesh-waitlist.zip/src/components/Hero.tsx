import { MessageCircle, Sparkles, Users, Zap, Compass } from 'lucide-react';

const WHATSAPP_COMMUNITY_URL = 'https://chat.whatsapp.com/LHQnObH3sWeGyJZszBh2Ct';

export function Hero() {
  return (
    <section
      id="hero-section"
      className="relative w-full pt-10 pb-16 sm:pt-16 sm:pb-24 px-4 sm:px-6 max-w-6xl mx-auto flex flex-col items-center text-center"
      aria-labelledby="hero-main-title"
    >
      {/* Top Floating Badge */}
      <div className="inline-flex items-center gap-2 bg-[#F5FF3D] border-[3px] border-black px-3.5 py-1.5 text-xs sm:text-sm font-extrabold uppercase shadow-brutal mb-6 sm:mb-8 -rotate-1 hover:rotate-0 transition-transform">
        <Sparkles className="w-4 h-4 text-black" aria-hidden="true" />
        <span>STUDENT NETWORKING THAT DOESN'T SUCK</span>
      </div>

      {/* Giant H1: FIND YOUR PEOPLE */}
      <div className="relative w-full max-w-5xl mb-6">
        <h1
          id="hero-main-title"
          className="text-black font-extrabold uppercase tracking-tighter leading-[0.92] text-[clamp(2.75rem,8.5vw,6.5rem)] font-heading drop-shadow-sm select-none"
        >
          FIND YOUR <span className="bg-[#F5FF3D] px-2 py-0.5 border-[3px] border-black inline-block shadow-brutal rotate-1">PEOPLE.</span>
        </h1>
      </div>

      {/* One-line subtext explaining INMESH for ALL students */}
      <p className="max-w-2xl text-base sm:text-xl font-bold text-neutral-900 mb-8 sm:mb-10 leading-relaxed px-2">
        The student networking platform built to find your circle in school, college, or university — skip the awkward small talk and discover peers on your exact wavelength.
      </p>

      {/* CTA Group: Clicking IS Joining directly via WhatsApp */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-4 w-full sm:w-auto mb-10">
        {/* Primary CTA button linking directly to WhatsApp waitlist */}
        <a
          href={WHATSAPP_COMMUNITY_URL}
          target="_blank"
          rel="noopener noreferrer"
          id="hero-cta-primary"
          className="btn-press inline-flex items-center justify-center gap-2.5 bg-[#F5FF3D] hover:bg-[#39FF14] text-black font-extrabold text-base sm:text-lg px-8 py-4 border-[3px] border-black shadow-brutal uppercase tracking-wide group hover:-rotate-1"
          aria-label="Join the INMESH waitlist on WhatsApp (opens in new tab)"
        >
          <MessageCircle className="w-5 h-5 fill-black text-white" aria-hidden="true" />
          <span>JOIN THE WAITLIST</span>
        </a>

        {/* Secondary WhatsApp direct button */}
        <a
          href={WHATSAPP_COMMUNITY_URL}
          target="_blank"
          rel="noopener noreferrer"
          id="hero-cta-whatsapp"
          className="btn-press inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#39FF14] text-black font-extrabold text-base sm:text-lg px-7 py-4 border-[3px] border-black shadow-brutal uppercase tracking-wide hover:rotate-1"
          aria-label="Join the INMESH WhatsApp community (opens in new tab)"
        >
          <span>OPEN WHATSAPP CHAT →</span>
        </a>
      </div>

      {/* Real Value Badges Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-3xl mt-4">
        <div className="bg-white border-[3px] border-black p-2.5 sm:p-3 shadow-brutal-sm flex items-center justify-center gap-2 font-extrabold text-xs sm:text-sm">
          <Zap className="w-4 h-4 text-black shrink-0" aria-hidden="true" />
          <span>100% STUDENT-FOUNDED</span>
        </div>
        <div className="bg-white border-[3px] border-black p-2.5 sm:p-3 shadow-brutal-sm flex items-center justify-center gap-2 font-extrabold text-xs sm:text-sm">
          <Users className="w-4 h-4 text-black shrink-0" aria-hidden="true" />
          <span>ZERO CORPORATE CRINGE</span>
        </div>
        <div className="bg-white border-[3px] border-black p-2.5 sm:p-3 shadow-brutal-sm flex items-center justify-center gap-2 font-extrabold text-xs sm:text-sm">
          <Compass className="w-4 h-4 text-black shrink-0" aria-hidden="true" />
          <span>OPEN TO ALL STUDENTS</span>
        </div>
      </div>
    </section>
  );
}
