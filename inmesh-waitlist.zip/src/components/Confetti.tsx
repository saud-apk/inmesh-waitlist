import { useMemo } from 'react';

const COLORS = ['#F5FF3D', '#39FF14', '#FF4338', '#00E5FF', '#000000', '#FFFFFF', '#FFAE00'];

export function Confetti() {
  const particles = useMemo(() => {
    return Array.from({ length: 48 }).map((_, i) => {
      const left = Math.random() * 100;
      const delay = Math.random() * 0.8;
      const size = 8 + Math.random() * 10;
      const color = COLORS[i % COLORS.length];
      const isCircle = i % 3 === 0;

      return {
        id: i,
        left: `${left}%`,
        delay: `${delay}s`,
        size: `${size}px`,
        color,
        isCircle,
      };
    });
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-30" aria-hidden="true">
      {particles.map((p) => (
        <div
          key={p.id}
          className="confetti-particle border-2 border-black"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            borderRadius: p.isCircle ? '9999px' : '0px',
            animationDelay: p.delay,
          }}
        />
      ))}
    </div>
  );
}
