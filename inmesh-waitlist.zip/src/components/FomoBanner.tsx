import { AlertTriangle, Flame, Lock } from 'lucide-react';

interface FomoBannerProps {
  waitlistCount: number;
}

const TOTAL_CAPACITY = 10000;

export function FomoBanner({ waitlistCount }: FomoBannerProps) {
  const percentage = Math.min(100, Math.round((waitlistCount / TOTAL_CAPACITY) * 100));
  const remaining = Math.max(0, TOTAL_CAPACITY - waitlistCount);

  return (
    <section
      id="fomo-section"
      className="w-full py-10 sm:py-16 px-4 sm:px-6 max-w-4xl mx-auto"
      aria-labelledby="fomo-section-title"
    >
      <div className="bg-[#F5FF3D] border-[3px] border-black p-6 sm:p-10 shadow-brutal-xl relative overflow-hidden">
        {/* Top Warning Strip */}
        <div className="flex items-center justify-between gap-2 flex-wrap mb-4 sm:mb-6">
          <div className="inline-flex items-center gap-1.5 bg-black text-[#39FF14] border-[2.5px] border-black px-3 py-1 text-xs font-black uppercase tracking-wider shadow-brutal-sm">
            <Flame className="w-4 h-4 text-[#39FF14]" aria-hidden="true" />
            <span>BATCH 01 ACCESS CAP</span>
          </div>

          <div className="inline-flex items-center gap-1.5 bg-white text-black border-[2.5px] border-black px-3 py-1 text-xs font-black uppercase tracking-wider shadow-brutal-sm">
            <Lock className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{remaining.toLocaleString()} SPOTS REMAINING</span>
          </div>
        </div>

        {/* Headline */}
        <h2
          id="fomo-section-title"
          className="text-2xl sm:text-4xl font-extrabold uppercase tracking-tight text-black font-heading mb-4 leading-tight"
        >
          ONLY OPENING TO THE FIRST 10,000 STUDENTS
        </h2>

        <p className="text-sm sm:text-base font-bold text-neutral-900 mb-6 leading-relaxed">
          To maintain high-density, high-trust student circles without spam or bot inflation, access will be released in controlled campus cohorts. Secure your spot on the priority registry before Batch 01 closes.
        </p>

        {/* Neubrutalist Progress Bar */}
        <div className="w-full mb-3">
          <div className="flex justify-between text-xs sm:text-sm font-black uppercase mb-1.5">
            <span>{waitlistCount.toLocaleString()} STUDENTS CLAIMED</span>
            <span>{percentage}% CAPACITY</span>
          </div>

          <div className="w-full h-8 bg-white border-[3px] border-black p-1 shadow-brutal-sm">
            <div
              className="h-full bg-[#39FF14] border-r-[2px] border-black transition-all duration-700 ease-out relative"
              style={{ width: `${percentage}%` }}
              role="progressbar"
              aria-valuenow={waitlistCount}
              aria-valuemin={0}
              aria-valuemax={TOTAL_CAPACITY}
              aria-label="Waitlist capacity progress"
            >
              <span className="sr-only">{percentage}% full</span>
            </div>
          </div>
        </div>

        {/* Micro Guarantee footer */}
        <div className="flex items-center gap-2 text-xs font-extrabold uppercase text-neutral-900 mt-4">
          <AlertTriangle className="w-4 h-4 shrink-0 text-black" aria-hidden="true" />
          <span>Priority invitation emails will be sent in order of submission timestamp.</span>
        </div>
      </div>
    </section>
  );
}
