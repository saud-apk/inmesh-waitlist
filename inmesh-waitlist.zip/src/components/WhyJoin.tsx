import { Heart, MessageSquare, Sparkles, Users } from 'lucide-react';

interface FeatureCard {
  id: string;
  tag: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  bgBadgeColor: string;
  accentCardBg: string;
  tiltClass: string;
}

export function WhyJoin() {
  const cards: FeatureCard[] = [
    {
      id: 'why-card-find-people',
      tag: 'REAL CONNECTION',
      title: 'FIND PEOPLE WHO GET YOU',
      description:
        'Whether you love late-night coding, making music, studying quietly in the library, or building silly projects, it is so much easier when you have friends who share what you genuinely care about.',
      icon: <Users className="w-7 h-7 text-black" aria-hidden="true" />,
      bgBadgeColor: 'bg-[#F5FF3D]',
      accentCardBg: 'bg-white',
      tiltClass: 'hover:-rotate-1',
    },
    {
      id: 'why-card-skip-smalltalk',
      tag: 'JUST BE YOURSELF',
      title: 'NO AWKWARD SMALL TALK',
      description:
        'You do not need a polished resume, a curated profile, or a rehearsed introduction. No stiff networking or cold messages — just honest conversations between students.',
      icon: <MessageSquare className="w-7 h-7 text-black" aria-hidden="true" />,
      bgBadgeColor: 'bg-[#39FF14]',
      accentCardBg: 'bg-[#FDFDF5]',
      tiltClass: 'hover:rotate-1',
    },
    {
      id: 'why-card-student-built',
      tag: 'MADE WITH CARE',
      title: 'BUILT BY A STUDENT',
      description:
        'Created by someone living student life alongside you every day — not a corporate committee trying to sell ads, farm engagement, or keep you doomscrolling.',
      icon: <Heart className="w-7 h-7 text-black" aria-hidden="true" />,
      bgBadgeColor: 'bg-[#F5FF3D]',
      accentCardBg: 'bg-white',
      tiltClass: 'hover:-rotate-1',
    },
    {
      id: 'why-card-open-to-all',
      tag: 'EVERYONE WELCOME',
      title: 'FOR EVERY STUDENT',
      description:
        'School, college, university, or learning on your own. Wherever you are in your education, if you are looking for good people to talk to, learn with, and hang out with, you belong here.',
      icon: <Sparkles className="w-7 h-7 text-black" aria-hidden="true" />,
      bgBadgeColor: 'bg-[#39FF14]',
      accentCardBg: 'bg-[#FDFDF5]',
      tiltClass: 'hover:rotate-1',
    },
  ];

  return (
    <section
      id="why-join-section"
      className="w-full py-12 sm:py-20 px-4 sm:px-6 max-w-6xl mx-auto"
      aria-labelledby="why-join-title"
    >
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
        <div className="inline-block bg-black text-[#F5FF3D] border-[3px] border-black px-3.5 py-1 text-xs font-black uppercase tracking-wider mb-4 shadow-brutal-sm -rotate-1">
          AN HONEST NOTE
        </div>
        <h2
          id="why-join-title"
          className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight text-black font-heading mb-4"
        >
          WHY JOIN <span className="bg-[#39FF14] px-2 py-0.5 border-[3px] border-black inline-block shadow-brutal rotate-1">INMESH?</span>
        </h2>
        <p className="text-base sm:text-lg font-bold text-neutral-800 leading-relaxed max-w-2xl mx-auto">
          Finding your circle as a student is surprisingly hard. Most people look like they already have their group, but almost everyone is wishing someone would say hello. INMESH is built to make that simple and comfortable.
        </p>
      </div>

      {/* Neubrutalist Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
        {cards.map((card, idx) => (
          <article
            key={card.id}
            id={card.id}
            className={`${card.accentCardBg} border-[3px] border-black p-6 sm:p-8 shadow-brutal-lg transition-all duration-200 ${card.tiltClass} flex flex-col justify-between`}
          >
            <div>
              <div className="flex items-center justify-between gap-3 mb-5">
                <span
                  className={`inline-block ${card.bgBadgeColor} border-[2.5px] border-black px-3 py-1 text-[11px] sm:text-xs font-black uppercase tracking-wider shadow-brutal-sm`}
                >
                  {card.tag}
                </span>
                <div className="w-12 h-12 bg-white border-[3px] border-black flex items-center justify-center shadow-brutal-sm">
                  {card.icon}
                </div>
              </div>

              <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-black font-heading mb-3">
                {card.title}
              </h3>

              <p className="text-sm sm:text-base font-medium text-neutral-800 leading-relaxed">
                {card.description}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t-[2.5px] border-black/20 flex items-center justify-between text-xs font-bold uppercase tracking-wide text-neutral-700">
              <span>INMESH PROMISE</span>
              <span className="text-black font-black">0{idx + 1}</span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
