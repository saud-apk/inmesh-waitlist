import { Github, Heart, Instagram, Mail, MessageCircle, Twitter } from 'lucide-react';

const WHATSAPP_COMMUNITY_URL = 'https://chat.whatsapp.com/LHQnObH3sWeGyJZszBh2Ct';
const CONTACT_EMAIL = 'officialsaudbusiness@gmail.com';
const TWITTER_URL = 'https://twitter.com/saud_apk';
const INSTAGRAM_URL = 'https://instagram.com/buildwithsaud';
const GITHUB_URL = 'https://github.com/saud-apk';

export function Footer() {
  return (
    <footer
      id="main-footer"
      className="w-full bg-white border-t-[3px] border-black pt-12 pb-8 px-4 sm:px-6 mt-12"
      role="contentinfo"
    >
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b-[2px] border-black/15">
        {/* Brand & Tagline */}
        <div className="flex flex-col items-center md:items-start gap-2 text-center md:text-left">
          <a
            href="#"
            id="footer-brand-chip"
            className="inline-flex items-center gap-2 bg-[#F5FF3D] border-[3px] border-black px-3.5 py-1 text-black font-extrabold text-lg uppercase tracking-wider shadow-brutal-sm hover:-rotate-1 transition-transform"
            aria-label="INMESH return to top"
          >
            <span className="w-3 h-3 bg-black inline-block"></span>
            <span>INMESH</span>
          </a>
          <p className="text-xs sm:text-sm font-extrabold uppercase tracking-wide text-neutral-800">
            FIND YOUR PEOPLE. <span className="font-medium text-neutral-600">The student networking platform for all students.</span>
          </p>
        </div>

        {/* Social & Contact Links */}
        <div className="flex items-center gap-2.5 flex-wrap justify-center">
          <a
            href={TWITTER_URL}
            target="_blank"
            rel="noopener noreferrer"
            id="footer-twitter-link"
            className="btn-press inline-flex items-center gap-1.5 bg-[#FDFDF5] hover:bg-[#F5FF3D] text-black font-extrabold text-xs px-3 py-2 border-[2.5px] border-black shadow-brutal-sm uppercase"
            aria-label="Saud Kavathekar on Twitter (opens in new tab)"
          >
            <Twitter className="w-3.5 h-3.5" aria-hidden="true" />
            <span>@saud_apk</span>
          </a>

          <a
            href={INSTAGRAM_URL}
            target="_blank"
            rel="noopener noreferrer"
            id="footer-instagram-link"
            className="btn-press inline-flex items-center gap-1.5 bg-[#FDFDF5] hover:bg-[#F5FF3D] text-black font-extrabold text-xs px-3 py-2 border-[2.5px] border-black shadow-brutal-sm uppercase"
            aria-label="Saud Kavathekar on Instagram (opens in new tab)"
          >
            <Instagram className="w-3.5 h-3.5" aria-hidden="true" />
            <span>@buildwithsaud</span>
          </a>

          <a
            href={GITHUB_URL}
            target="_blank"
            rel="noopener noreferrer"
            id="footer-github-link"
            className="btn-press inline-flex items-center gap-1.5 bg-[#FDFDF5] hover:bg-[#F5FF3D] text-black font-extrabold text-xs px-3 py-2 border-[2.5px] border-black shadow-brutal-sm uppercase"
            aria-label="Saud Kavathekar on GitHub (opens in new tab)"
          >
            <Github className="w-3.5 h-3.5" aria-hidden="true" />
            <span>saud-apk</span>
          </a>

          <a
            href={`mailto:${CONTACT_EMAIL}`}
            id="footer-email-link"
            className="btn-press inline-flex items-center gap-1.5 bg-[#FDFDF5] hover:bg-[#39FF14] text-black font-extrabold text-xs px-3 py-2 border-[2.5px] border-black shadow-brutal-sm uppercase"
            aria-label="Email Saud Kavathekar"
          >
            <Mail className="w-3.5 h-3.5" aria-hidden="true" />
            <span>EMAIL</span>
          </a>

          <a
            href={WHATSAPP_COMMUNITY_URL}
            target="_blank"
            rel="noopener noreferrer"
            id="footer-whatsapp-link"
            className="btn-press inline-flex items-center gap-1.5 bg-[#25D366] text-black font-extrabold text-xs px-3 py-2 border-[2.5px] border-black shadow-brutal-sm uppercase"
            aria-label="INMESH WhatsApp Community (opens in new tab)"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-black text-white" aria-hidden="true" />
            <span>WHATSAPP</span>
          </a>
        </div>
      </div>

      {/* Bottom credits & Saud Kavathekar attribution */}
      <div className="max-w-6xl mx-auto pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left text-xs font-bold text-neutral-800">
        <div className="flex items-center gap-1.5 justify-center">
          <span>Made with</span>
          <Heart className="w-3.5 h-3.5 text-black fill-black" aria-hidden="true" />
          <span className="font-extrabold uppercase">by Saud Kavathekar</span>
        </div>

        <div className="text-neutral-600">
          © {new Date().getFullYear()} INMESH. All rights reserved. Built for students worldwide.
        </div>
      </div>
    </footer>
  );
}
