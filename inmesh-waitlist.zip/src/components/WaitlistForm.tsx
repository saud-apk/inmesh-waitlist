import { ArrowUpRight, MessageCircle, ShieldCheck, Sparkles, Users } from 'lucide-react';

const WHATSAPP_COMMUNITY_URL = 'https://chat.whatsapp.com/LHQnObH3sWeGyJZszBh2Ct';

{/* 
  PLACEHOLDER FOR FUTURE VERIFIED SOCIAL PROOF / TESTIMONIALS:
  When real member stories and verified community quotes become available,
  they can be added here. Never use fabricated reviews or artificial counters.
*/}

export function WaitlistForm() {
  return (
    <section
      id="waitlist-section"
      className="relative w-full py-12 sm:py-20 px-4 sm:px-6 max-w-3xl mx-auto scroll-mt-24"
      aria-labelledby="waitlist-section-title"
    >
      <div className="bg-white border-[3px] border-black p-6 sm:p-10 shadow-brutal-xl relative">
        {/* Decorative corner tag */}
        <div className="absolute -top-4 -right-2 sm:-right-4 bg-[#39FF14] border-[3px] border-black px-3 py-1 text-xs font-black uppercase tracking-wider shadow-brutal-sm rotate-3">
          DIRECT ADMISSION
        </div>

        <div>
          <div className="mb-6 sm:mb-8 text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 bg-[#F5FF3D] border-[2.5px] border-black px-3 py-1 text-xs font-black uppercase tracking-wider shadow-brutal-sm mb-3">
              <Sparkles className="w-3.5 h-3.5 text-black" aria-hidden="true" />
              <span>JOIN THE COMMUNITY NOW</span>
            </div>
            <h2
              id="waitlist-section-title"
              className="text-2xl sm:text-4xl font-extrabold uppercase tracking-tight text-black font-heading mb-3"
            >
              READY TO FIND YOUR CIRCLE?
            </h2>
            <p className="text-sm sm:text-base font-bold text-neutral-800 leading-relaxed">
              Click below to jump straight into the official INMESH WhatsApp community. Clicking joins the waitlist and puts you directly in touch with fellow students — no sign-up forms, no passwords, no hassle.
            </p>
          </div>

          {/* Direct CTA Button linking to WhatsApp */}
          <div className="pt-2 pb-4">
            <a
              href={WHATSAPP_COMMUNITY_URL}
              target="_blank"
              rel="noopener noreferrer"
              id="waitlist-direct-button"
              className="btn-press w-full inline-flex items-center justify-center gap-3 bg-[#F5FF3D] hover:bg-[#39FF14] text-black font-extrabold text-base sm:text-xl px-6 py-5 border-[3px] border-black shadow-brutal uppercase tracking-wider transition-all group"
              aria-label="Join the INMESH waitlist directly on WhatsApp (opens in new tab)"
            >
              <MessageCircle className="w-6 h-6 fill-black text-white shrink-0" aria-hidden="true" />
              <span>JOIN THE WAITLIST</span>
              <ArrowUpRight className="w-6 h-6 shrink-0 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" aria-hidden="true" />
            </a>
          </div>

          {/* Value points strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-4 border-t-[2.5px] border-black/15 text-xs font-bold text-neutral-800">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-black shrink-0" aria-hidden="true" />
              <span>100% Free for all students</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-black shrink-0" aria-hidden="true" />
              <span>Real students, zero bots</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-black font-extrabold">✓</span>
              <span>Direct WhatsApp group access</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
