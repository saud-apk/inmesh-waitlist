import { Sparkles } from 'lucide-react';

{/* 
  PLACEHOLDER FOR FUTURE VERIFIED SOCIAL PROOF / PARTNER CAMPUSES:
  Once verified student counts, campus chapters, or testimonials are officially confirmed,
  populate this section with real, verified community data. Never use fabricated numbers.
*/}

const STUDENT_INTERESTS = [
  'CODING',
  'DESIGN',
  'STARTUPS',
  'STUDY SESSIONS',
  'MUSIC',
  'HACKATHONS',
  'PHOTOGRAPHY',
  'WRITING',
  'FILM & CREATIVE',
  'GAMING',
  'RESEARCH',
  'OPEN SOURCE',
  'CHESS & ESPORTS',
  'FITNESS & RUNNING',
];

export function SocialProofMarquee() {
  return (
    <section
      id="student-interests-strip"
      className="w-full bg-[#F5FF3D] border-y-[3px] border-black py-4 overflow-hidden shadow-brutal my-8 select-none"
      aria-label="Student interests and community topics"
    >
      <div className="max-w-6xl mx-auto px-4 mb-2 flex items-center justify-center gap-2 text-black font-extrabold text-xs sm:text-sm uppercase tracking-wider">
        <Sparkles className="w-4 h-4" aria-hidden="true" />
        <span>CONNECT OVER WHAT YOU LOVE • BUILT FOR STUDENTS EVERYWHERE</span>
      </div>

      <div className="relative w-full overflow-hidden flex">
        <div className="animate-marquee flex items-center gap-3 whitespace-nowrap py-1">
          {/* Loop genuine student interests */}
          {[...STUDENT_INTERESTS, ...STUDENT_INTERESTS].map((interest, idx) => {
            const isGreen = idx % 3 === 0;
            const isWhite = idx % 3 === 1;

            return (
              <span
                key={`${interest}-${idx}`}
                className={`inline-flex items-center gap-1.5 px-3 py-1 border-[2.5px] border-black text-xs sm:text-sm font-extrabold uppercase shadow-[2px_2px_0px_#000] ${
                  isGreen
                    ? 'bg-[#39FF14] text-black'
                    : isWhite
                    ? 'bg-white text-black'
                    : 'bg-black text-[#F5FF3D]'
                }`}
              >
                <span>★</span>
                <span>{interest}</span>
              </span>
            );
          })}
        </div>
      </div>
    </section>
  );
}
