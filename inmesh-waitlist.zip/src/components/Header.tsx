const WHATSAPP_COMMUNITY_URL = 'https://chat.whatsapp.com/LHQnObH3sWeGyJZszBh2Ct';

export function Header() {
  return (
    <header
      id="main-header"
      className="sticky top-0 z-50 w-full bg-[#FDFDF5]/95 backdrop-blur-md border-b-[3px] border-black transition-all"
    >
      <div className="max-w-6xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2">
        {/* INMESH Wordmark Chip */}
        <a
          href="#"
          id="brand-logo-chip"
          className="inline-flex items-center gap-1.5 bg-[#F5FF3D] border-[3px] border-black px-2.5 sm:px-3 py-1 text-black font-extrabold text-sm sm:text-base tracking-wider uppercase shadow-brutal-sm hover:-rotate-1 transition-transform"
          aria-label="INMESH homepage"
        >
          <span className="w-2.5 h-2.5 bg-black inline-block"></span>
          <span>INMESH</span>
        </a>

        {/* Real Static Community Status & Direct WhatsApp CTA */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div
            id="header-community-status"
            className="flex items-center gap-2 bg-white border-[3px] border-black px-2.5 sm:px-3.5 py-1 text-xs sm:text-sm font-bold shadow-brutal-sm"
          >
            <span className="relative flex h-2.5 w-2.5" aria-hidden="true">
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#39FF14] border border-black"></span>
            </span>
            <span className="text-black font-extrabold uppercase text-[11px] sm:text-xs tracking-tight">
              COMMUNITY OPEN
            </span>
          </div>

          <a
            href={WHATSAPP_COMMUNITY_URL}
            target="_blank"
            rel="noopener noreferrer"
            id="header-cta-button"
            className="bg-[#39FF14] text-black font-extrabold text-xs sm:text-sm px-3 sm:px-4 py-1.5 border-[3px] border-black shadow-brutal-sm hover:translate-x-[2px] hover:translate-y-[2px] hover:shadow-[1px_1px_0px_#000] active:translate-x-[3px] active:translate-y-[3px] transition-all uppercase whitespace-nowrap"
          >
            JOIN WAITLIST
          </a>
        </div>
      </div>
    </header>
  );
}
