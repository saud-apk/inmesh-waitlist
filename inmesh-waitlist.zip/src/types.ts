export interface WaitlistSubmission {
  id: string;
  email: string;
  college: string;
  timestamp: number;
  spotNumber: number;
}

export interface FormErrors {
  email?: string;
  college?: string;
  general?: string;
}
