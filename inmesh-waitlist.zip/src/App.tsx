import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { SocialProofMarquee } from './components/SocialProofMarquee';
import { WhyJoin } from './components/WhyJoin';
import { WaitlistForm } from './components/WaitlistForm';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#FDFDF5] bg-subtle-grid flex flex-col justify-between selection:bg-[#F5FF3D] selection:text-black">
      {/* 1. Sticky Top Bar */}
      <Header />

      {/* Semantic Main Content Area */}
      <main id="main-content" className="flex-grow flex flex-col items-center">
        {/* 2. Hero Section */}
        <Hero />

        {/* 3. Student Interests Marquee Strip */}
        <SocialProofMarquee />

        {/* 4. Why Join Section */}
        <WhyJoin />

        {/* 5. Direct Waitlist Admission Section */}
        <WaitlistForm />
      </main>

      {/* 6. Footer with contact and social links */}
      <Footer />
    </div>
  );
}
